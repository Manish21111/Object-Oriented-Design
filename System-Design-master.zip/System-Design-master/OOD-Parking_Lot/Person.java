public class Person {
	private String person_id;		//some govt id, say aadhar card no.
	
	public String getPersonId() {
		return person_id;
	}
	
	public void setPersonId(String person_id) {
		this.person_id = person_id;
	}
	
}
