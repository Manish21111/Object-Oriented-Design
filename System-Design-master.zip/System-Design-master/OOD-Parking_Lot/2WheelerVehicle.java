class 2WheelerVehicle extends Vehicle {
	
}
