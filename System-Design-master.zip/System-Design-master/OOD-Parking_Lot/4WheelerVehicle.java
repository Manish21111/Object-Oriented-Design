class 4WheelerVehicle extends Vehicle {
	
}
